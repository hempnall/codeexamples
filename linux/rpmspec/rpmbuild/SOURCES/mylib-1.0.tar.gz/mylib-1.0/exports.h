extern "C" void say_something();
