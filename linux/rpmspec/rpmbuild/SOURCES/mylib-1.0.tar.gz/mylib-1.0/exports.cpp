#include <iostream>
#include "exports.h"

void say_something() {

	std::cout << "Hello, i'm a library...." << std::endl;

}
