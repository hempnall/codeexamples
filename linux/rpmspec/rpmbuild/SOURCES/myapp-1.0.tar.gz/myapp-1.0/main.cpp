#include <iostream>
#include <exports.h>

int main() {

	std::cout << "Testing this rpm thing...." << std::endl;
	say_something();
	return 0;


}
